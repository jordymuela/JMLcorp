
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";



--
-- Banco de Dados: ` Sistema de Avaliação de Produtos`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela para a tabela `review_table`
--

CREATE TABLE `review_table` (
  `review_id` int(11) NOT NULL,
  `user_name` varchar(200) NOT NULL,
  `user_rating` int(1) NOT NULL,
  `user_review` text NOT NULL,
  `datetime` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Inserindo dados para a tabela `review_table`
--

INSERT INTO `review_table` (`review_id`, `user_name`, `user_rating`, `user_review`, `datetime`) VALUES
(6, 'Lorem Ipsum', 4, 'A qualidade da câmera é fenomenal, especialmente em condições de pouca luz.', 1621935691),
(7, 'Jane Doe', 5, 'A duração da bateria me dura o dia todo, mesmo com uso intenso. Impressionante!', 1621939888),
(8, 'John Doe', 5, 'Adoro o design elegante e o desempenho ultrarrápido deste iPhone!', 1621940010);

--
-- Índices para as tabelas exportadas
--

--
-- Índices para a tabela `review_table`
--
ALTER TABLE `review_table`
  ADD PRIMARY KEY (`review_id`);

--
-- AUTO_INCREMENT para as tabelas exportadas
--

--
-- AUTO_INCREMENT para a tabela `review_table`
--
ALTER TABLE `review_table`
  MODIFY `review_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

